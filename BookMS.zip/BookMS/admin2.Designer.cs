﻿namespace BookMS
{
    partial class admin2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            button1 = new Button();
            button2 = new Button();
            button5 = new Button();
            button6 = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            button3 = new Button();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = SystemColors.Control;
            dataGridView1.BorderStyle = BorderStyle.Fixed3D;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6, Column7 });
            dataGridView1.Dock = DockStyle.Left;
            dataGridView1.Location = new Point(0, 0);
            dataGridView1.MultiSelect = false;
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(1048, 864);
            dataGridView1.TabIndex = 0;
            dataGridView1.Click += dataGridView1_Click;
            // 
            // Column1
            // 
            Column1.FillWeight = 20F;
            Column1.HeaderText = "书号";
            Column1.MinimumWidth = 8;
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.FillWeight = 35.81818F;
            Column2.HeaderText = "书名";
            Column2.MinimumWidth = 8;
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.FillWeight = 30.81818F;
            Column3.HeaderText = "作者";
            Column3.MinimumWidth = 8;
            Column3.Name = "Column3";
            // 
            // Column4
            // 
            Column4.FillWeight = 20.81818F;
            Column4.HeaderText = "价格";
            Column4.MinimumWidth = 8;
            Column4.Name = "Column4";
            // 
            // Column5
            // 
            Column5.FillWeight = 35.81818F;
            Column5.HeaderText = "出版社";
            Column5.MinimumWidth = 8;
            Column5.Name = "Column5";
            // 
            // Column6
            // 
            Column6.FillWeight = 25.81818F;
            Column6.HeaderText = "类别";
            Column6.MinimumWidth = 8;
            Column6.Name = "Column6";
            // 
            // Column7
            // 
            Column7.FillWeight = 20.81818F;
            Column7.HeaderText = "库存";
            Column7.MinimumWidth = 8;
            Column7.Name = "Column7";
            // 
            // button1
            // 
            button1.BackColor = Color.Gainsboro;
            button1.Font = new Font("微软雅黑", 12F, FontStyle.Regular, GraphicsUnit.Point, 134);
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(1148, 136);
            button1.Name = "button1";
            button1.Size = new Size(150, 61);
            button1.TabIndex = 1;
            button1.Text = "添加图书";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Gainsboro;
            button2.Font = new Font("微软雅黑", 12F, FontStyle.Regular, GraphicsUnit.Point, 134);
            button2.ForeColor = SystemColors.ActiveCaptionText;
            button2.Location = new Point(1390, 136);
            button2.Name = "button2";
            button2.Size = new Size(150, 61);
            button2.TabIndex = 2;
            button2.Text = "修改图书";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.Gainsboro;
            button5.Font = new Font("微软雅黑", 12F, FontStyle.Regular, GraphicsUnit.Point, 134);
            button5.ForeColor = SystemColors.ActiveCaptionText;
            button5.Location = new Point(1390, 250);
            button5.Name = "button5";
            button5.Size = new Size(150, 61);
            button5.TabIndex = 5;
            button5.Text = "刷新";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.Gainsboro;
            button6.Font = new Font("微软雅黑", 12F, FontStyle.Regular, GraphicsUnit.Point, 134);
            button6.ForeColor = SystemColors.ActiveCaptionText;
            button6.Location = new Point(1148, 250);
            button6.Name = "button6";
            button6.Size = new Size(150, 61);
            button6.TabIndex = 6;
            button6.Text = "删除图书";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(1291, 347);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(197, 30);
            textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(1291, 400);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(197, 30);
            textBox2.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonFace;
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(1138, 61);
            label1.Name = "label1";
            label1.Size = new Size(172, 24);
            label1.TabIndex = 9;
            label1.Text = "当前选中的图书是：";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(1316, 61);
            label2.Name = "label2";
            label2.Size = new Size(56, 24);
            label2.TabIndex = 10;
            label2.Text = "NULL";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(1291, 450);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(197, 30);
            textBox3.TabIndex = 11;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(1291, 501);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(197, 30);
            textBox4.TabIndex = 12;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(1291, 552);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(197, 30);
            textBox5.TabIndex = 13;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(1291, 597);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(197, 30);
            textBox6.TabIndex = 14;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(24, 24);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(1179, 347);
            label3.Name = "label3";
            label3.Size = new Size(64, 24);
            label3.TabIndex = 16;
            label3.Text = "书号：";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(1179, 400);
            label4.Name = "label4";
            label4.Size = new Size(64, 24);
            label4.TabIndex = 17;
            label4.Text = "书名：";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(1179, 450);
            label5.Name = "label5";
            label5.Size = new Size(64, 24);
            label5.TabIndex = 18;
            label5.Text = "作者：";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(1179, 501);
            label6.Name = "label6";
            label6.Size = new Size(64, 24);
            label6.TabIndex = 19;
            label6.Text = "价格：";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(1179, 552);
            label7.Name = "label7";
            label7.Size = new Size(82, 24);
            label7.TabIndex = 20;
            label7.Text = "出版社：";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(1179, 597);
            label8.Name = "label8";
            label8.Size = new Size(64, 24);
            label8.TabIndex = 21;
            label8.Text = "类别：";
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ActiveBorder;
            button3.Location = new Point(1159, 668);
            button3.Name = "button3";
            button3.Size = new Size(164, 60);
            button3.TabIndex = 22;
            button3.Text = "查询";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click_1;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ActiveBorder;
            button4.Location = new Point(1376, 668);
            button4.Name = "button4";
            button4.Size = new Size(164, 60);
            button4.TabIndex = 23;
            button4.Text = "返回";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // admin2
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1618, 864);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            ForeColor = SystemColors.ActiveCaptionText;
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "admin2";
            Text = "图书管理页面";
            Load += admin2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button button1;
        private Button button2;
        private Button button5;
        private Button button6;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
        private Label label2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private ContextMenuStrip contextMenuStrip1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Button button3;
        private Button button4;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
    }
}