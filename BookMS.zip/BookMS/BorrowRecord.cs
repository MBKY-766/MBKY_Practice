﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class BorrowRecord : Form
    {
        //根据ID传递书的信息（将ID作为主键）
        string ID = "";
        //获取选中的借书记录信息
        string id = "";
        //记录初始是否有记录
        Boolean empty = true;
        public BorrowRecord()
        {
            InitializeComponent();
        }
        private void BorrowRecord_Load(object sender, EventArgs e)
        {
            Table();
            if (!empty)//如果有数据，默认选中第一行
            {
                label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();//获取默认编号
                ID = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();//获取该书的ID
                id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();//获取借书编号
            }
        }
        //从数据库读取数据显示在表格控件中
        public void Table()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = $"select * from BorrowRecord where BorrowerID = '{Data.UID}'";//读取该用户的借阅记录
            IDataReader dc = dao.read(sql);//执行该命令的对象
            if (dc.Read())//有数据
            {
                empty = false;
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString(), dc[5].ToString());//读取第一个数据
                while (dc.Read())//接着循环读取，直到读完
                {
                    //将读到的数据添加到表格中
                    dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString(), dc[5].ToString());
                }
            }
            else//没有数据
            {
                MessageBox.Show("目前暂无记录");
            }
            dc.Close();//释放资源
            dao.DaoClose();//关闭sql连接

        }
        //选择借书记录
        private void dataGridView1_Click(object sender, EventArgs e)
        {
            if (!empty)//如果有数据
            {
                label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();//显示选中的借书记录
                ID = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();//获取该书的ID
                id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();//获取借书编号
            }
            else
            {
                MessageBox.Show("目前暂无记录");
            }
        }
        
        //返回按钮
        private void button2_Click(object sender, EventArgs e)
        {
            //关闭当前页面
            this.Close();
            //跳转回用户页面
            user1 user1Page = (user1)Application.OpenForms["user1"];//获取名为user1的页面实例。Application.OpenForms是一个集合，它包含了当前应用程序中所有打开的窗体。
            //如果获取到了user1页面的实例且不为空，就使用user1Page.Show()重新显示该页面。
            if (user1Page != null)
            {
                // 显示之前被隐藏的页面
                user1Page.Show();
            }
        }
    }
}
