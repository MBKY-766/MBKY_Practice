﻿namespace BookMS
{
    partial class admin1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            系统ToolStripMenuItem = new ToolStripMenuItem();
            退出ToolStripMenuItem = new ToolStripMenuItem();
            图书管理ToolStripMenuItem = new ToolStripMenuItem();
            借阅管理ToolStripMenuItem = new ToolStripMenuItem();
            图书统计ToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { 系统ToolStripMenuItem, 图书管理ToolStripMenuItem, 借阅管理ToolStripMenuItem, 图书统计ToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 32);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // 系统ToolStripMenuItem
            // 
            系统ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 退出ToolStripMenuItem });
            系统ToolStripMenuItem.Name = "系统ToolStripMenuItem";
            系统ToolStripMenuItem.Size = new Size(62, 28);
            系统ToolStripMenuItem.Text = "系统";
            // 
            // 退出ToolStripMenuItem
            // 
            退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            退出ToolStripMenuItem.Size = new Size(270, 34);
            退出ToolStripMenuItem.Text = "退出";
            退出ToolStripMenuItem.Click += 退出ToolStripMenuItem_Click;
            // 
            // 图书管理ToolStripMenuItem
            // 
            图书管理ToolStripMenuItem.Name = "图书管理ToolStripMenuItem";
            图书管理ToolStripMenuItem.Size = new Size(98, 28);
            图书管理ToolStripMenuItem.Text = "图书管理";
            图书管理ToolStripMenuItem.Click += 图书管理ToolStripMenuItem_Click;
            // 
            // 借阅管理ToolStripMenuItem
            // 
            借阅管理ToolStripMenuItem.Name = "借阅管理ToolStripMenuItem";
            借阅管理ToolStripMenuItem.Size = new Size(98, 28);
            借阅管理ToolStripMenuItem.Text = "借阅管理";
            借阅管理ToolStripMenuItem.Click += 借阅管理ToolStripMenuItem_Click;
            // 
            // 图书统计ToolStripMenuItem
            // 
            图书统计ToolStripMenuItem.Name = "图书统计ToolStripMenuItem";
            图书统计ToolStripMenuItem.Size = new Size(98, 28);
            图书统计ToolStripMenuItem.Text = "图书统计";
            图书统计ToolStripMenuItem.Click += 图书统计ToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("华文新魏", 22F, FontStyle.Regular, GraphicsUnit.Point, 134);
            label1.ForeColor = Color.SteelBlue;
            label1.Location = new Point(230, 194);
            label1.Name = "label1";
            label1.Size = new Size(340, 44);
            label1.TabIndex = 1;
            label1.Text = "欢迎管理员登录!";
            // 
            // admin1
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "admin1";
            Text = "管理员主界面";
            Load += admin1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem 系统ToolStripMenuItem;
        private ToolStripMenuItem 图书管理ToolStripMenuItem;
        private ToolStripMenuItem 借阅管理ToolStripMenuItem;
        private Label label1;
        private ToolStripMenuItem 图书统计ToolStripMenuItem;
        private ToolStripMenuItem 退出ToolStripMenuItem;
    }
}