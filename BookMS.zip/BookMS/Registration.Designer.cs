﻿namespace BookMS
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            button1 = new Button();
            label3 = new Label();
            textBox3 = new TextBox();
            label4 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            label6 = new Label();
            button2 = new Button();
            SuspendLayout();
            // 
            // textBox2
            // 
            textBox2.Font = new Font("华文楷体", 12F);
            textBox2.Location = new Point(351, 238);
            textBox2.Name = "textBox2";
            textBox2.PasswordChar = '*';
            textBox2.Size = new Size(223, 39);
            textBox2.TabIndex = 8;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("华文楷体", 12F);
            textBox1.Location = new Point(351, 170);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(223, 39);
            textBox1.TabIndex = 7;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("微软雅黑", 12F);
            label2.Location = new Point(259, 237);
            label2.Name = "label2";
            label2.Size = new Size(86, 31);
            label2.TabIndex = 6;
            label2.Text = "密码：";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("微软雅黑", 12F);
            label1.Location = new Point(259, 169);
            label1.Name = "label1";
            label1.Size = new Size(86, 31);
            label1.TabIndex = 5;
            label1.Text = "账户：";
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlLightLight;
            button1.Location = new Point(259, 422);
            button1.Name = "button1";
            button1.Size = new Size(160, 48);
            button1.TabIndex = 9;
            button1.Text = "立即注册";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("微软雅黑", 22F, FontStyle.Regular, GraphicsUnit.Point, 134);
            label3.Location = new Point(222, 70);
            label3.Name = "label3";
            label3.Size = new Size(465, 57);
            label3.TabIndex = 10;
            label3.Text = "欢迎来到用户注册系统";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("华文楷体", 12F);
            textBox3.Location = new Point(351, 299);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(223, 39);
            textBox3.TabIndex = 11;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("微软雅黑", 12F);
            label4.Location = new Point(259, 299);
            label4.Name = "label4";
            label4.Size = new Size(86, 31);
            label4.TabIndex = 12;
            label4.Text = "姓名：";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Checked = true;
            radioButton1.Location = new Point(370, 360);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(53, 28);
            radioButton1.TabIndex = 13;
            radioButton1.TabStop = true;
            radioButton1.Text = "男";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(498, 359);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(53, 28);
            radioButton2.TabIndex = 14;
            radioButton2.Text = "女";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("微软雅黑", 12F);
            label6.Location = new Point(259, 356);
            label6.Name = "label6";
            label6.Size = new Size(86, 31);
            label6.TabIndex = 16;
            label6.Text = "性别：";
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ControlLightLight;
            button2.Location = new Point(448, 422);
            button2.Name = "button2";
            button2.Size = new Size(160, 48);
            button2.TabIndex = 17;
            button2.Text = "返回";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // Registration
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(895, 518);
            Controls.Add(button2);
            Controls.Add(label6);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label4);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(button1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Registration";
            Text = "用户注册";
            Load += Registration_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox2;
        private TextBox textBox1;
        private Label label2;
        private Label label1;
        private Button button1;
        private Label label3;
        private TextBox textBox3;
        private Label label4;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Label label6;
        private Button button2;
    }
}