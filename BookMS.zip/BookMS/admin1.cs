﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class admin1 : Form
    {
        public admin1()
        {
            InitializeComponent();
            this.FormClosed += Admin1_FormClosed; // 订阅FormClosed事件，关联到对应的处理方法
        }

        private void Admin1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();//窗体关闭时退出程序
        }

        private void admin1_Load(object sender, EventArgs e)
        {

        }

        private void 图书管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            admin2 admin = new admin2();//创建admin2页面-图书管理页面
            admin.ShowDialog();//跳转到图书管理页面
        }

        private void 借阅管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            BorrowManagement bm = new BorrowManagement();//创建借阅管理对象
            bm.ShowDialog();//跳转到借阅管理页面
        }
        
        private void 图书统计ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            BookCount bc = new BookCount();//创建图书统计对象
            bc.ShowDialog(); //跳转到图书统计页面
        }
        //退出
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
