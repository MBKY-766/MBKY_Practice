﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class user1 : Form
    {
        public user1()
        {
            InitializeComponent();
            // 订阅FormClosed事件，关联到对应的处理方法
            this.FormClosed += User1_FormClosed;
        }

        private void User1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();//窗体关闭时退出程序
        }

        private void user1_Load(object sender, EventArgs e)
        {
            Table();
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + " " + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();//获取书号+书名
        }
        
        public void Table()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = "select * from Book";//读取数据的命令
            IDataReader dc = dao.read(sql);//执行该命令的对象
            while (dc.Read())
            {
                //将读到的数据添加到表格中
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString(), dc[5].ToString(), dc[6].ToString());
            }
            dc.Close();//释放资源
            dao.DaoClose();//关闭sql连接

        }
        //点击选择图书事务，更新标签
        private void dataGridView1_Click(object sender, EventArgs e)
        {
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + " " + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();//获取书号+书名
        }
        //查询
        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();//清空旧数据

            Dao dao = new Dao();

            // 构建动态的SQL查询语句，初始化为选择所有列的语句
            string sql = "select * from Book where 1 = 1";

            // 用于收集查询条件参数的列表，方便后续拼接SQL语句
            List<string> conditions = new List<string>();

            // 根据书号进行条件判断和添加
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                conditions.Add($"BookID like '%{textBox1.Text}%'");
            }

            // 根据书名进行条件判断和添加
            if (!string.IsNullOrEmpty(textBox2.Text))
            {
                conditions.Add($"BookName like '%{textBox2.Text}%'");
            }

            // 根据作者进行条件判断和添加
            if (!string.IsNullOrEmpty(textBox3.Text))
            {
                conditions.Add($"Author like '%{textBox3.Text}%'");
            }

            // 根据价格进行条件判断和添加，这里假设价格输入框中输入的是合法的数值格式，如有需要可添加格式校验逻辑
            if (!string.IsNullOrEmpty(textBox4.Text))
            {
                conditions.Add($"Price like {textBox4.Text}");
            }

            // 根据出版社进行条件判断和添加
            if (!string.IsNullOrEmpty(textBox5.Text))
            {
                conditions.Add($"Publisher like '%{textBox5.Text}%'");
            }

            // 根据类别进行条件判断和添加
            if (!string.IsNullOrEmpty(textBox6.Text))
            {
                conditions.Add($"Category like '%{textBox6.Text}%'");
            }

            // 将收集到的条件拼接进SQL语句中，如果有多个条件，用 AND 连接
            if (conditions.Count > 0)
            {
                sql += " AND " + string.Join(" AND ", conditions);
            }

            IDataReader dc = dao.read(sql);
            while (dc.Read())
            {
                // 将读到的数据添加到表格中，此处假设表格列数与查询结果列数对应，如有不同需调整索引和添加逻辑
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString(), dc[5].ToString(), dc[6].ToString());
            }
            dc.Close();//释放资源
            dao.DaoClose();//关闭sql连接
        }
        //刷新
        private void button5_Click(object sender, EventArgs e)
        {
            Table();
        }

        //借书
        private void button1_Click(object sender, EventArgs e)
        {
            //对于选中的图书：库存-1 增加一条借书记录
            //选中的图书
            string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();//获取书号-当前选中的书的id
            //判断库存是否大于1
            //获取该书的库存
            int stock = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[6].Value);
            if (stock > 0)
            {
                //有剩余，库存-1
                Dao dao = new Dao();
                string sql = $"update Book set Stock = Stock -1 where BookID = '{id}'";
                //消息提示
                if (dao.Execute(sql) > 0)
                {
                    MessageBox.Show($"成功借出《{dataGridView1.SelectedRows[0].Cells[1].Value.ToString()}》");
                    Table();//刷新表格
                    //添加借书记录,借阅期限默认为30天
                    string sql1 = $"insert into BorrowRecord (BookID,BorrowerID,BorrowerName,BorrowDate,DueDate)values('{id}','{Data.UID}','{Data.UName}',getdate(),dateadd(day, 30, getdate()))";
                    //插入记录
                    dao.Execute(sql1);
                }
                else
                {
                    //借书失败，没选中图书
                    MessageBox.Show("借书失败，请先选中图书");
                }
                dao.DaoClose();
            }
            else
            {
                //无剩余，提示
                MessageBox.Show("该书库存不足，请先联系管理员购入该图书");
            }
        }
        //查看借书记录
        private void BorrowRecord_Click(object sender, EventArgs e)
        {
            this.Hide();//隐藏当前页面
            BorrowRecord br = new BorrowRecord();
            br.ShowDialog();//跳转到借书记录页面
        }
        //退出用户系统
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //帮助按钮
        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("请联系管理员获取帮助");
        }

        
    }
}
