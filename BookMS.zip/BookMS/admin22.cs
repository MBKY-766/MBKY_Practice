﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class admin22 : Form
    {
        //根据ID传递书的信息（将ID作为主键）
        string ID = "";
        public admin22()
        {
            InitializeComponent();
        }
        //带参构造函数-传递该书的信息
        public admin22(string bookID, string bookName, string author, string price, string publisher, string category, string stock)
        {
            InitializeComponent();
            ID = textBox1.Text = bookID;
            textBox2.Text = bookName;
            textBox3.Text = author;
            textBox4.Text = price;
            textBox5.Text = publisher;
            textBox6.Text = category;
            textBox7.Text = stock;
        }
        //修改按钮
        private void button1_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6, textBox7 };
            Boolean flag = true;
            foreach (TextBox box in textBoxes)
            {
                if (box.Text == "")
                {
                    flag = false;
                }
            }
            //没有空值，修改
            if (flag)
            {
                Dao dao = new Dao();//连接数据库
                string sql = $"update Book set BookID='{textBox1.Text}',BookName='{textBox2.Text}',Author='{textBox3.Text}',Price={textBox4.Text},Publisher='{textBox5.Text}',Category='{textBox6.Text}',Stock={textBox7.Text} where BookID='{ID}'";//修改图书
                int n = dao.Execute(sql);//执行sql语句-返回的是受影响的行数
                if (n > 0)
                {
                    MessageBox.Show("修改成功");
                    this.Close();//关掉此页面
                }
                else
                {
                    MessageBox.Show("修改失败");
                }
            }
            //有空值,提示
            else
            {
                MessageBox.Show("输入不允许有空");
            }

        }
        //清空按钮
        private void button2_Click(object sender, EventArgs e)
        {
            
            TextBox[] textBoxes = { textBox2, textBox4, textBox5, textBox6, textBox7 };
            foreach (TextBox textBox in textBoxes)
            {
                textBox.Text = "";
            }
        }

        private void admin22_Load(object sender, EventArgs e)
        {

        }
    }
}
