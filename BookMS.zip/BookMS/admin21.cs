﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class admin21 : Form
    {
        public admin21()
        {
            InitializeComponent();
        }
        private void admin21_Load(object sender, EventArgs e)
        {

        }
        //添加按钮
        private void button1_Click(object sender, EventArgs e)
        {
            Dao dao = new Dao();//连接数据库
            TextBox[] textBoxes = { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6, textBox7 };
            Boolean flag = true;
            foreach (TextBox box in textBoxes)
            {
                if (box.Text == "")
                {
                    flag = false;
                }
            }
            //没有空值
            //BookID存在
            string sql1 = $"select * from Book where BookID ='{textBox1.Text}'";
            IDataReader dc = dao.read(sql1);
            if (dc.Read())//读到了返回真-存在该BookID
            {
                MessageBox.Show("该书号已存在，请重新输入", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //BookID不存在，可以添加
                if (flag)//输入是否为空
                {

                    string sql = $"insert into Book values('{textBox1.Text}','{textBox2.Text}','{textBox3.Text}',{textBox4.Text},'{textBox5.Text}','{textBox6.Text}',{textBox7.Text})";//插入图书
                    int n = dao.Execute(sql);//执行sql语句-返回的是受影响的行数
                    if (n > 0)
                    {
                        MessageBox.Show("添加成功");
                        //this.Close();//关闭该窗口
                    }
                    else
                    {
                        MessageBox.Show("添加失败");
                    }
                    //清空
                    myClear();
                }
                //有空值,提示
                else
                {
                    MessageBox.Show("输入不允许有空");
                }
            }
            dao.DaoClose();

        }
        //清空按钮
        private void button2_Click(object sender, EventArgs e)
        {
            myClear();
        }
        //清空函数
        private void myClear()
        {
            TextBox[] textBoxes = { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6, textBox7 };
            foreach (TextBox textBox in textBoxes)
            {
                textBox.Text = "";
            }
        }

    }
}
