﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BookMS
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void Registration_Load(object sender, EventArgs e)
        {

        }
        //立即注册
        private void button1_Click(object sender, EventArgs e)
        {
            Dao dao = new Dao();
            string id = $"{textBox1.Text}";
            string psw = $"{textBox2.Text}";
            string name = $"{textBox3.Text}";
            string sex = "";
            System.Windows.Forms.TextBox[] textBoxes = {textBox1, textBox2, textBox3};
            Boolean unEmpty = true;
            foreach (System.Windows.Forms.TextBox box in textBoxes)
            {
                if (box.Text == "")
                {
                    unEmpty = false;//注册信息存在空值
                }
            }
            if (radioButton1.Checked == true)
            {
                //男
                sex = "男";
            }
            else
            {
                //女
                sex = "女";
            }
            if (unEmpty)//注册信息不存在空值
            {
                string sql = $"select * from t_user where id = '{id}'";//查询该账户是否已经注册
                IDataReader dc = dao.read(sql);
                Boolean flag = dc.Read(); //查询到该账户返回真
                if (flag)
                {
                    //账户已经存在，提示
                    MessageBox.Show("该账户已存在，请重新输入");
                }
                else
                {
                    //账户不存在，将账户，密码存入user表中
                    string sql1 = $"insert t_user values('{id}','{name}','{sex}','{psw}')";
                    dao.Execute(sql1);//执行插入操作
                    MessageBox.Show("注册成功!");
                }
            }
            else
            {
                MessageBox.Show("用户信息存在空值，请检查","提示信息",MessageBoxButtons.OK,MessageBoxIcon.Warning);//提示存在空值
            }
        }
        //返回到登录页面
        private void button2_Click(object sender, EventArgs e)
        {
            //关闭当前页面
            this.Close();
            //跳转回登录页面
            login loginPage = (login)Application.OpenForms["login"];//获取名为login的页面实例。Application.OpenForms是一个集合，它包含了当前应用程序中所有打开的窗体。
            //如果获取到了login页面的实例且不为空，就使用loginPage.Show()重新显示该页面。
            if (loginPage != null)
            {
                // 显示之前被隐藏的页面
                loginPage.Show();
            }
        }
    }
}
