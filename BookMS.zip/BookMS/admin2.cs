﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class admin2 : Form
    {
        public admin2()
        {
            InitializeComponent();
        }
        //加载admin2窗体
        private void admin2_Load(object sender, EventArgs e)
        {
            Table();
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + " " + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();//获取书号+书名

        }
        //从数据库读取数据显示在表格控件中
        public void Table()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = "select * from Book";//读取数据的命令
            IDataReader dc = dao.read(sql);//执行该命令的对象
            while (dc.Read())
            {
                //将读到的数据添加到表格中
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString(), dc[5].ToString(), dc[6].ToString());
            }
            dc.Close();//释放资源
            dao.DaoClose();//关闭sql连接

        }

        //删除图书-button6
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();//获取书号-当前选中的书
                DialogResult dr = MessageBox.Show("确认删除吗？", "信息提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);//确认删除提示
                if (dr == DialogResult.OK)
                {
                    //点的ok-确认删除
                    string sql = $"delete from Book where BookID = '{id}'";
                    Dao dao = new Dao();
                    if (dao.Execute(sql) > 0)
                    {
                        //返回的受影响行数大于0
                        MessageBox.Show("删除成功");
                        Table();//刷新表格
                    }
                    else
                    {
                        MessageBox.Show("删除失败" + sql);
                    }
                    dao.DaoClose();
                }


            }
            catch
            {
                MessageBox.Show("请先选中图书", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //点击选择图书事务，更新标签
        private void dataGridView1_Click(object sender, EventArgs e)
        {
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + " " + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();//获取书号+书名
        }

        //添加图书
        private void button1_Click(object sender, EventArgs e)
        {
            
            admin21 a = new admin21();
            a.ShowDialog();//弹出添加图书页面
            Table();//添加后刷新
        }
        //修改图书
        private void button2_Click(object sender, EventArgs e)
        {
            string bookID = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            string bookName = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            string author = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            string price = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            string publisher = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            string category = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            string stock = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            admin22 a = new admin22(bookID, bookName, author, price, publisher, category, stock);//创建修改图书窗体
            a.ShowDialog();//弹出修改图书页面
            Table();//修改后刷新
        }
        //刷新
        private void button5_Click(object sender, EventArgs e)
        {
            //调用Table();清空旧数据再读取
            Table();
        }
        /*//书号查询
        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = $"select * from Book where BookID = '{textBox1.Text}'";//读取数据的命令
            IDataReader dc = dao.read(sql);//执行该命令的对象
            while (dc.Read())
            {
                //将读到的数据添加到表格中
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString(), dc[5].ToString(), dc[6].ToString());
            }
            dc.Close();//释放资源
            dao.DaoClose();//关闭sql连接
        }
        //书名查询
        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = $"select * from Book where BookID = '{textBox2.Text}'";//读取数据的命令
            IDataReader dc = dao.read(sql);//执行该命令的对象
            while (dc.Read())
            {
                //将读到的数据添加到表格中
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString(), dc[5].ToString(), dc[6].ToString());
            }
            dc.Close();//释放资源
            dao.DaoClose();//关闭sql连接
        }*/
        //查询-多条件
        private void button3_Click_1(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();//清空旧数据

            Dao dao = new Dao();

            // 构建动态的SQL查询语句，初始化为选择所有列的语句
            string sql = "select * from Book where 1 = 1";

            // 用于收集查询条件参数的列表，方便后续拼接SQL语句
            List<string> conditions = new List<string>();

            // 根据书号进行条件判断和添加
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                conditions.Add($"BookID like '%{textBox1.Text}%'");
            }

            // 根据书名进行条件判断和添加
            if (!string.IsNullOrEmpty(textBox2.Text))
            {
                conditions.Add($"BookName like '%{textBox2.Text}%'");
            }

            // 根据作者进行条件判断和添加
            if (!string.IsNullOrEmpty(textBox3.Text))
            {
                conditions.Add($"Author like '%{textBox3.Text}%'");
            }

            // 根据价格进行条件判断和添加，这里假设价格输入框中输入的是合法的数值格式，如有需要可添加格式校验逻辑
            if (!string.IsNullOrEmpty(textBox4.Text))
            {
                conditions.Add($"Price like {textBox4.Text}");
            }

            // 根据出版社进行条件判断和添加
            if (!string.IsNullOrEmpty(textBox5.Text))
            {
                conditions.Add($"Publisher like '%{textBox5.Text}%'");
            }

            // 根据类别进行条件判断和添加
            if (!string.IsNullOrEmpty(textBox6.Text))
            {
                conditions.Add($"Category like '%{textBox6.Text}%'");
            }

            // 将收集到的条件拼接进SQL语句中，如果有多个条件，用 AND 连接
            if (conditions.Count > 0)
            {
                sql += " AND " + string.Join(" AND ", conditions);
            }

            IDataReader dc = dao.read(sql);
            while (dc.Read())
            {
                // 将读到的数据添加到表格中，此处假设表格列数与查询结果列数对应，如有不同需调整索引和添加逻辑
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString(), dc[5].ToString(), dc[6].ToString());
            }
            dc.Close();//释放资源
            dao.DaoClose();//关闭sql连接
        }
        //返回
        private void button4_Click(object sender, EventArgs e)
        {

            //关闭当前页面
            this.Close();
            //跳转回管理员页面
            admin1 admin1Page = (admin1)Application.OpenForms["admin1"];//获取名为admin1的页面实例。Application.OpenForms是一个集合，它包含了当前应用程序中所有打开的窗体。
            //如果获取到了admin1页面的实例且不为空，就使用admin1Page.Show()重新显示该页面。
            if (admin1Page != null)
            {
                // 显示之前被隐藏的页面
                admin1Page.Show();
            }
        }
    }
}
