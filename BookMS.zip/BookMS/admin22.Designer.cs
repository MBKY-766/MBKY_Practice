﻿namespace BookMS
{
    partial class admin22
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            textBox7 = new TextBox();
            label7 = new Label();
            textBox6 = new TextBox();
            label6 = new Label();
            textBox5 = new TextBox();
            label5 = new Label();
            textBox4 = new TextBox();
            label4 = new Label();
            textBox3 = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveBorder;
            button2.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 134);
            button2.ForeColor = SystemColors.ActiveCaptionText;
            button2.Location = new Point(509, 367);
            button2.Name = "button2";
            button2.Size = new Size(214, 47);
            button2.TabIndex = 31;
            button2.Text = "清空";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveBorder;
            button1.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 134);
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(134, 367);
            button1.Name = "button1";
            button1.Size = new Size(221, 47);
            button1.TabIndex = 30;
            button1.Text = "修改";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox7
            // 
            textBox7.Font = new Font("华文细黑", 11.999999F);
            textBox7.Location = new Point(121, 288);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(264, 41);
            textBox7.TabIndex = 29;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("华文细黑", 11.999999F);
            label7.Location = new Point(19, 291);
            label7.Name = "label7";
            label7.Size = new Size(84, 26);
            label7.TabIndex = 28;
            label7.Text = "库存：";
            // 
            // textBox6
            // 
            textBox6.Font = new Font("华文细黑", 11.999999F);
            textBox6.Location = new Point(518, 202);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(264, 41);
            textBox6.TabIndex = 27;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("华文细黑", 11.999999F);
            label6.Location = new Point(416, 205);
            label6.Name = "label6";
            label6.Size = new Size(84, 26);
            label6.TabIndex = 26;
            label6.Text = "类别：";
            // 
            // textBox5
            // 
            textBox5.Font = new Font("华文细黑", 11.999999F);
            textBox5.Location = new Point(121, 199);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(264, 41);
            textBox5.TabIndex = 25;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("华文细黑", 11.999999F);
            label5.Location = new Point(19, 202);
            label5.Name = "label5";
            label5.Size = new Size(108, 26);
            label5.TabIndex = 24;
            label5.Text = "出版社：";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("华文细黑", 11.999999F);
            textBox4.Location = new Point(518, 118);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(264, 41);
            textBox4.TabIndex = 23;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("华文细黑", 11.999999F);
            label4.Location = new Point(416, 121);
            label4.Name = "label4";
            label4.Size = new Size(84, 26);
            label4.TabIndex = 22;
            label4.Text = "价格：";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("华文细黑", 11.999999F);
            textBox3.Location = new Point(121, 118);
            textBox3.Name = "textBox3";
            textBox3.ReadOnly = true;
            textBox3.Size = new Size(264, 41);
            textBox3.TabIndex = 21;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("华文细黑", 11.999999F);
            label3.Location = new Point(19, 121);
            label3.Name = "label3";
            label3.Size = new Size(84, 26);
            label3.TabIndex = 20;
            label3.Text = "作者：";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("华文细黑", 11.999999F);
            textBox2.Location = new Point(518, 39);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(264, 41);
            textBox2.TabIndex = 19;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("华文细黑", 11.999999F);
            label2.Location = new Point(416, 42);
            label2.Name = "label2";
            label2.Size = new Size(84, 26);
            label2.TabIndex = 18;
            label2.Text = "书名：";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("华文细黑", 11.999999F);
            textBox1.Location = new Point(121, 36);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(264, 41);
            textBox1.TabIndex = 17;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("华文细黑", 11.999999F);
            label1.Location = new Point(19, 39);
            label1.Name = "label1";
            label1.Size = new Size(84, 26);
            label1.TabIndex = 16;
            label1.Text = "书号：";
            // 
            // admin22
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox7);
            Controls.Add(label7);
            Controls.Add(textBox6);
            Controls.Add(label6);
            Controls.Add(textBox5);
            Controls.Add(label5);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "admin22";
            Text = "修改图书";
            Load += admin22_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private TextBox textBox7;
        private Label label7;
        private TextBox textBox6;
        private Label label6;
        private TextBox textBox5;
        private Label label5;
        private TextBox textBox4;
        private Label label4;
        private TextBox textBox3;
        private Label label3;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
    }
}