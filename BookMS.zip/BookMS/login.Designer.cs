﻿namespace BookMS
{
    partial class login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            radioButtonUser = new RadioButton();
            radioButtonAdmin = new RadioButton();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("华文新魏", 22F, FontStyle.Regular, GraphicsUnit.Point, 134);
            label1.Location = new Point(164, 75);
            label1.Name = "label1";
            label1.Size = new Size(459, 44);
            label1.TabIndex = 0;
            label1.Text = "欢迎来到图书管理系统";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("华文楷体", 12F);
            label2.Location = new Point(223, 164);
            label2.Name = "label2";
            label2.Size = new Size(84, 27);
            label2.TabIndex = 1;
            label2.Text = "账户：";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("华文楷体", 12F);
            label3.Location = new Point(223, 232);
            label3.Name = "label3";
            label3.Size = new Size(84, 27);
            label3.TabIndex = 2;
            label3.Text = "密码：";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("华文楷体", 12F);
            textBox1.Location = new Point(296, 164);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(223, 39);
            textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("华文楷体", 12F);
            textBox2.Location = new Point(293, 232);
            textBox2.Name = "textBox2";
            textBox2.PasswordChar = '*';
            textBox2.Size = new Size(223, 39);
            textBox2.TabIndex = 4;
            // 
            // radioButtonUser
            // 
            radioButtonUser.AutoSize = true;
            radioButtonUser.Checked = true;
            radioButtonUser.Font = new Font("华文楷体", 12F);
            radioButtonUser.Location = new Point(270, 288);
            radioButtonUser.Name = "radioButtonUser";
            radioButtonUser.Size = new Size(85, 31);
            radioButtonUser.TabIndex = 5;
            radioButtonUser.TabStop = true;
            radioButtonUser.Text = "用户";
            radioButtonUser.UseVisualStyleBackColor = true;
            // 
            // radioButtonAdmin
            // 
            radioButtonAdmin.AutoSize = true;
            radioButtonAdmin.Font = new Font("华文楷体", 12F);
            radioButtonAdmin.Location = new Point(410, 288);
            radioButtonAdmin.Name = "radioButtonAdmin";
            radioButtonAdmin.Size = new Size(109, 31);
            radioButtonAdmin.TabIndex = 6;
            radioButtonAdmin.TabStop = true;
            radioButtonAdmin.Text = "管理员";
            radioButtonAdmin.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Font = new Font("华文楷体", 12F);
            button1.Location = new Point(243, 343);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 7;
            button1.Text = "登录";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("华文楷体", 12F);
            button2.Location = new Point(410, 343);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 8;
            button2.Text = "注册";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // login
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(radioButtonAdmin);
            Controls.Add(radioButtonUser);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "login";
            Text = "登录界面";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBox1;
        private TextBox textBox2;
        private RadioButton radioButtonUser;
        private RadioButton radioButtonAdmin;
        private Button button1;
        private Button button2;
    }
}
